function viewAllTable(){
    return new Promise((resolve)=>{
        fetch('https://45c8udghcj.execute-api.ap-southeast-1.amazonaws.com/default/GetItem')
        .then(res => res.json())
        .then(data => resolve(data))
    })
}

module.exports = {
    viewAllTable : viewAllTable
}